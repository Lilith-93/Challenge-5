<html>

<head>
   <title>Exercice des commandes.</title>
   <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
   <link href="assets/style.CSS" type="text/css" rel="stylesheet" />
<link href="assets/bootstrap.min.css" type="text/css" rel="stylesheet" />
</head>

<body>
<?php $tags = explode( ' ', 'horreur fantastique action western thriller comédie drame romance historique' );
print_r($tags);
?>
</body>

</html>
