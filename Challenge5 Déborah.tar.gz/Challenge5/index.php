<html>

<head>
   <title>Exercice des commandes.</title>
   <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
   <link href="assets/style.css" type="text/css" rel="stylesheet" />
<link href="assets/bootstrap.min.css" type="text/css" rel="stylesheet" />
</head>

<body>
	<h1>Challenge n°5 (et pas Channel n°5)</h1>
	<article class="col-md-6"> <a href="Exo1.php"><img src="img/commandes.jpg" class="col-md-6"/><br/>
	<h2>On passe commande ?</h2></a>
	</article>
	<article class="col-md-6"> <a href="Exo2.php"><img src="img/film.jpg" class="col-md-6"/><br/>
	<h2>On s'matte un film ?</h2></a>
	</article>
	<article class="col-md-6"> <a href="Exo3.php"><img src="img/corbeille.jpg" class="col-md-6"/><br/>
	<h2>Jolie corbeille de fruits !</h2></a>
	</article>
	<article class="col-md-6"> <a href="Exo4.php"><img src="img/prenom.jpg" class="col-md-6"/><br/>
	<h2>Les prénoms en H sont les plus beaux !</h2></a>
	</article>
</body>

</html>

