<?php
//EXERCICE 4
$prenoms = ["Harry", "Hilary", "Harrington", "Hagrid", "Holmes"];
$res = array_splice( $prenoms, '2' , '1' );
print_r($prenoms);
?>